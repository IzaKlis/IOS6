//
//  ViewController.h
//  IOS6
//
//  Created by student on 14/11/2023.
//  Copyright © 2023 me.kozlowski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic,weak)IBOutlet UIButton *informationButton;
@property (nonatomic,weak)IBOutlet UIImageView *imageWI;
@end

